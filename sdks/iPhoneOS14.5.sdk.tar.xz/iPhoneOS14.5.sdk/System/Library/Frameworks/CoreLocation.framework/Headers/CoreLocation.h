/*
 *  CoreLocation.h
 *  CoreLocation
 *
 *  Copyright (c) 2008-2010 Apple Inc. All rights reserved.
 *
 */


#ifndef __CORELOCATION__
#define __CORELOCATION__

#ifndef __CL_INDIRECT__
#define __CL_INDIRECT__
#endif

#import <CoreLocation/CLAvailability.h>
#import <CoreLocation/CLErrorDomain.h>
#import <CoreLocation/CLError.h>
#import <CoreLocation/CLRegion.h>
#import <CoreLocation/CLCircularRegion.h>
#import <CoreLocation/CLBeaconRegion.h>
#import <CoreLocation/CLBeaconIdentityConstraint.h>
#import <CoreLocation/CLHeading.h>
#import <CoreLocation/CLLocation.h>
#import <CoreLocation/CLLocationManager.h>
#import <CoreLocation/CLLocationManagerDelegate.h>
#import <CoreLocation/CLLocationManager+CLVisitExtensions.h>
#import <CoreLocation/CLPlacemark.h>
#import <CoreLocation/CLGeocoder.h>
#import <CoreLocation/CLVisit.h>

#endif /* __CORELOCATION__ */
